################################################################################
#   AIM
################################################################################
 example code to train a  feedforward and convolutional neural network

 the code trains a convolutional neural network to predict peptide binding to MHC

################################################################################
#	DATA PREPARATION
################################################################################

# these commands can be ignored, they just convert MN data format to a table:---

awk '{ print $1 "\t" $3 "\t" $2 "\t0"}' data/c000 > data/c000_p
awk '{ print $1 "\t" $3 "\t" $2 "\t1"}' data/c001 > data/c001_p
awk '{ print $1 "\t" $3 "\t" $2 "\t2"}' data/c002 > data/c002_p
awk '{ print $1 "\t" $3 "\t" $2 "\t3"}' data/c003 > data/c003_p
awk '{ print $1 "\t" $3 "\t" $2 "\t4"}' data/c004 > data/c004_p

cat data/c000_p data/c001_p data/c002_p data/c003_p data/c004_p > data/all_data.txt
sort -r data/all_data.txt | head -10000 > data/all_data_10000.txt
sort -r data/all_data.txt | head -1000 > data/all_data_1000.txt

# the following code requires a data table in the following format:

------------------------------------------------------------------------------
| peptide AA seq | MHC name | target value (binding affinity) | partitioning |
------------------------------------------------------------------------------

################################################################################
#	TRAIN FNN
################################################################################

# feed forward network:m

mkdir test_fnn
python scripts/nn_train_tf.py \
    -infile data/all_data_1000.txt \
    -outdir test_fnn/ \
    -encoding blosum \
    -blosum data/BLOSUM50 \
    -mhc_seq_table data/pseudosequences.all.X.dat \
    -epochs 5

################################################################################
#	TRAIN CNN
################################################################################

# this model trains 5-fold cross validation:

mkdir test_cnn
python scripts/cnn_train_tf.py \
    -infile data/all_data_1000.txt \
    -outdir test_cnn/ \
    -encoding blosum \
    -blosum data/BLOSUM50 \
    -mhc_seq_table data/pseudosequences.all.X.dat \
    -epochs 5

python scripts/calc_AUC.py -infile test/predictions.txt -header -col_target 2 -col_pred 3

# there is also a script that can be used to make predictions only:
scripts/cnn_pred_tf.py
