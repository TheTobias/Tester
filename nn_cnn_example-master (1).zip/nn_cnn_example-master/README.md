# nn_cnn_example
example code to train FNN and CNN in tensorflow

### Data

Peptides binding to MHC molecules (log transformed binding affinity measurements)
```
------------------------------------------------------------------------------
| peptide AA seq | MHC name | target value (binding affinity) | partitioning |
------------------------------------------------------------------------------
```

### Train networks

Train a feedforwrad neural network:
```
mkdir test_fnn
python scripts/nn_train_tf.py \
    -infile data/all_data_1000.txt \
    -outdir test_fnn/ \
    -encoding blosum \
    -blosum data/BLOSUM50 \
    -mhc_seq_table data/pseudosequences.all.X.dat \
    -epochs 5
```
Train a convolutional neural network:
```
mkdir test_cnn
python scripts/cnn_train_tf.py \
    -infile data/all_data_1000.txt \
    -outdir test_cnn/ \
    -encoding blosum \
    -blosum data/BLOSUM50 \
    -mhc_seq_table data/pseudosequences.all.X.dat \
    -epochs 5
```

### Predict with trained nets

Make predictions with the trained feedforward net:
```
python scripts/nn_pred_tf.py \
    -infile data/all_data_1000.txt \
    -outdir test_fnn/test_ \
    -param_dir test_fnn/ \
    -encoding blosum \
    -blosum data/BLOSUM50 \
    -mhc_seq_table data/pseudosequences.all.X.dat 
```
Make predictions with the trained convolutional net:
```
python scripts/cnn_pred_tf.py \
    -infile data/all_data_1000.txt \
    -outdir test_cnn/test_ \
    -param_dir test_cnn/
    -encoding blosum \
    -blosum data/BLOSUM50 \
    -mhc_seq_table data/pseudosequences.all.X.dat 
```
