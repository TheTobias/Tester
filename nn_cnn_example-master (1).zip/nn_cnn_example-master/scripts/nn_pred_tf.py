#!/usr/bin/env python

"""
Make predictions with FNN
"""

from __future__ import print_function
import argparse
import sys
import os
import time
import random
import re
import csv
from operator import itemgetter

import math
import numpy as np
from sklearn.preprocessing import normalize
from sklearn.metrics import roc_auc_score
import tensorflow as tf

import data_io_tf
import NN_tf

################################################################################
#   SUBROUTINES
################################################################################

def iterate_minibatches(pep, mhc, targets, batchsize):
    assert pep.shape[0] == mhc.shape[0] == targets.shape[0]
    # shuffle:
    indices = np.arange(len(pep))
    np.random.shuffle(indices)
    #for start_idx in range(0, len(pep) - batchsize + 1, batchsize):
    for start_idx in range(0, len(pep), batchsize):
        excerpt = indices[start_idx:start_idx + batchsize]
        yield pep[excerpt],mhc[excerpt],targets[excerpt]


################################################################################
#	PARSE COMMANDLINE OPTIONS
################################################################################

parser = argparse.ArgumentParser()
parser.add_argument('-infile', '--infile',  help="input file")
parser.add_argument('-outdir', '--outdir',  help="output directory")
parser.add_argument('-param_dir', '--param_dir',  help="output directory")
parser.add_argument('-batch_size', '--batch_size',  help="Mini batch size, default = 20", default=20)
parser.add_argument('-n_seed', '--n_seed',  help="Number of seeds, default = 1", default=1)
parser.add_argument('-encoding', '--encoding',  help="encoding, default = sparse", default="blosum")
parser.add_argument('-blosum', '--blosum', help="file with BLOSUM matrix")
parser.add_argument('-mhc_seq_table', '--mhc_seq_table',  help="file with MHC name -> MHC sequences", default='data/pseudosequences.all.X.dat')
parser.add_argument('-gpu', '--gpu', action="store_true", help="Use GPU, default = False", default=False)
parser.add_argument('-new_data', '--new_data', action="store_true", help="Predict new data (no target values/partitions), default = False", default=False)
args = parser.parse_args()



# get input data (peps/proteins):
if args.infile != None:
    print("# Input: " + args.infile )
    inputfile = args.infile
else:
    sys.stderr.write("Please specify input!\n")
    sys.exit(2)

# get output data:
if args.outdir != None:
    print("# Output directory: " + args.outdir )
    outdir = args.outdir
else:
    sys.stderr.write("Please specify output directory!\n")
    sys.exit(2)

# get parameter directory:
if args.param_dir != None:
    print("# Output directory: " + args.param_dir )
    param_dir = args.param_dir
else:
    sys.stderr.write("Please specify parameter directory!\n")
    sys.exit(2)


try:
    BATCH_SIZE=int(args.batch_size)
    print("# batch size: " + str(BATCH_SIZE))
except:
    sys.stderr.write("Problem with mini batch size specification (option -batch_size)!\n")
    sys.exit(2)


try:
    SEED=range(1,(int(args.n_seed)+1))
    print("# number of seeds: " + str(int(args.n_seed)))
except:
    sys.stderr.write("Problem with number of seeds specification (option -learning_rate)!\n")
    sys.exit(2)

try:
    ENCODING=args.encoding
    print("# encoding: " + str(ENCODING))
except:
    sys.stderr.write("Problem with sequence encoding specification (option -encoding)!\n")
    sys.exit(2)

if ENCODING == "blosum":
    try:
        blosumfile=args.blosum
        print("# Blosum matrix file: " + str(blosumfile))
    except:
        sys.stderr.write("Blosum encoding requires blosum matrix file! (option -blosum)!\n")
        sys.exit(2)

mhc_table=args.mhc_seq_table
print("# MHC pseudo sequences: " + mhc_table)

# Set to GPU:
if args.gpu==True:
    device_name = "/gpu:0"
else:
    device_name = "/cpu:0"

# # SET SEED:
# np.random.seed(1)
# tf.set_random_seed(1)

config = tf.ConfigProto(intra_op_parallelism_threads=2, inter_op_parallelism_threads=2, allow_soft_placement=True)


################################################################################
#   LOAD AND PARTITION DATA
################################################################################
print("# Loading data...")

# read data:
X_pep,X_mhc,y,part_vec=data_io_tf.read_pMHC(inputfile)

N_PART=len(set(part_vec))
if N_PART==0:
    N_PART=5

# MHC name to sequence:
mhc_name=np.array(X_mhc)
X_mhc = data_io_tf.mhc_name2seq(X_mhc,mhc_table)

# save pep AA seq:
pep_aa = np.array(X_pep)

# encode data (list of numpy nd-arrays):
if ENCODING == "sparse":
    X_pep = data_io_tf.enc_list_sparse(X_pep)
    X_mhc = data_io_tf.enc_list_sparse(X_mhc)
elif ENCODING == "blosum":
    blosum = data_io_tf.read_blosum_MN(blosumfile)
    X_pep = data_io_tf.enc_list_bl(X_pep, blosum)
    X_mhc = data_io_tf.enc_list_bl(X_mhc, blosum)

MAX_PEP_LEN=X_pep.shape[1]
MAX_MHC_LEN=X_mhc.shape[1]

################################################################################
#   PREDICT NETWORKS
################################################################################


# prepare output file:
outfile=open(outdir + "predictions.txt","w")

if args.new_data==True:
    print("# predicting new data...")
    outfile.write("peptide\tmhc\tprediction\n")

    all_pred=[]

    for t in range(0,N_PART):
        for v in range(0,N_PART):
            if t != v:
                for s in SEED:

                    # set up network:
                    MODEL = np.load(param_dir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_1']
                    hyper_params = np.load(param_dir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_2']
                    N_FEATURES=int(hyper_params[0])
                    N_HID=int(hyper_params[1])
                    N_FILTERS=int(hyper_params[2])

                    with tf.device(device_name):
                        if MODEL=="FNN":
                            predictions,l_in_pep,l_in_mhc = NN_tf.build_FNN(max_pep_len=MAX_PEP_LEN,max_mhc_len=MAX_MHC_LEN,n_features=N_FEATURES,n_hid=N_HID)
                        else:
                            print("Error: unknown model")
                    # start tf session:
                    sess = tf.Session(config=config)
                    # variable initialization:
                    sess.run(tf.global_variables_initializer())

                    # set parameters:
                    best_params = np.load(param_dir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_0']
                    params=tf.trainable_variables()

                    for i in range(0,len(params)):
                        sess.run(params[i].assign(best_params[i]))

                    # predict model:
                    all_pred.append( sess.run(predictions, feed_dict={l_in_pep: X_pep, l_in_mhc: X_mhc}) )

                    # close session:
                    sess.close()
                    tf.reset_default_graph()

    # calculate mean predictions of all models:
    all_pred=np.array(all_pred)
    pred = np.mean(all_pred, axis=0)


    for i in range(0,pep_aa.shape[0]):
        outfile.write(str(pep_aa[i]) + "\t" + str(mhc_name[i]) + "\t" + str(pred[i]) + "\n")

else:
    print("# predicting test data...")
    outfile.write("peptide\tmhc\ttarget\tprediction\n")

    # initialize variables for AUC calculation:
    y_test_all=[]
    pred_vec_all=[]

    for t in range(0,N_PART):
        print("# predicting test set " + str(t) + "...")
        # get test set:
        test_idx = np.where(part_vec == t)

        X_pep_test = X_pep[test_idx]
        X_mhc_test = X_mhc[test_idx]
        y_test = y[test_idx]

        pep_test_aa = pep_aa[test_idx]
        mhc_test_name = mhc_name[test_idx]

        all_pred=[]
        for v in range(0,N_PART):
            if t != v:
                for s in SEED:

                    # set up network:
                    MODEL = np.load(param_dir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_1']
                    hyper_params = np.load(param_dir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_2']
                    N_FEATURES=int(hyper_params[0])
                    N_HID=int(hyper_params[1])
                    N_FILTERS=int(hyper_params[2])

                    with tf.device(device_name):
                        if MODEL=="FNN":
                            predictions,l_in_pep,l_in_mhc = NN_tf.build_FNN(max_pep_len=MAX_PEP_LEN,max_mhc_len=MAX_MHC_LEN,n_features=N_FEATURES,n_hid=N_HID)
                        else:
                            print("Error: unknown model")
                    # start tf session:
                    sess = tf.Session(config=config)
                    # variable initialization:
                    sess.run(tf.global_variables_initializer())

                    # set parameters:
                    best_params = np.load(param_dir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_0']
                    params=tf.trainable_variables()

                    for i in range(0,len(params)):
                        sess.run(params[i].assign(best_params[i]))

                    # predict model:
                    all_pred.append( sess.run(predictions, feed_dict={l_in_pep: X_pep_test, l_in_mhc: X_mhc_test}) )
                    # close session:
                    sess.close()
                    tf.reset_default_graph()

        # calculate mean predictions of all models:
        all_pred=np.array(all_pred)
        pred = np.mean(all_pred, axis=0)

        # save pred and target
        y_test_all.append(list(y_test))
        pred_vec_all.append(list(pred))


        for i in range(0,pep_test_aa.shape[0]):
            outfile.write(str(pep_test_aa[i]) + "\t" + str(mhc_test_name[i]) + "\t" + str(y_test[i]) + "\t" + str(pred[i][0]) + "\n")

    # calculate performance (AUC):
    tmp = [item for sublist in y_test_all for item in sublist]
    y_test_all=np.array(tmp)
    y_binary = np.where(y_test_all>=0.42562, 1,0)

    tmp = [item for sublist in pred_vec_all for item in sublist]
    pred_vec_all = np.array(tmp)


    auc = roc_auc_score(y_binary, pred_vec_all)
    outfile.write("# AUC: " + str(auc) + "\n")

outfile.close()
