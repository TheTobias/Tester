#!/usr/bin/env python

"""
Functions for specifiying neural network architectures.
"""

from __future__ import print_function
import argparse
import sys
import os
import time

import math
import numpy as np

import tensorflow as tf

def build_CNN(n_features, n_hid, n_filters):

    # input:
    l_in_pep = tf.placeholder(tf.float32, shape=[None,None,n_features])
    l_in_mhc = tf.placeholder(tf.float32, shape=[None,None,n_features])

    # convolutional layers on peptide:
    l_conv_pep_1 = tf.layers.conv1d(inputs=l_in_pep, filters=n_filters, kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_pep_3 = tf.layers.conv1d(inputs=l_in_pep, filters=n_filters, kernel_size=3, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_pep_5 = tf.layers.conv1d(inputs=l_in_pep, filters=n_filters, kernel_size=5, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_pep_7 = tf.layers.conv1d(inputs=l_in_pep, filters=n_filters, kernel_size=7, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_pep_9 = tf.layers.conv1d(inputs=l_in_pep, filters=n_filters, kernel_size=9, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)

    # convolutional layers on MHC:
    l_conv_mhc_1 = tf.layers.conv1d(inputs=l_in_mhc, filters=n_filters, kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_mhc_3 = tf.layers.conv1d(inputs=l_in_mhc, filters=n_filters, kernel_size=3, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_mhc_5 = tf.layers.conv1d(inputs=l_in_mhc, filters=n_filters, kernel_size=5, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_mhc_7 = tf.layers.conv1d(inputs=l_in_mhc, filters=n_filters, kernel_size=7, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_mhc_9 = tf.layers.conv1d(inputs=l_in_mhc, filters=n_filters, kernel_size=9, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)

    # second convolutional layer:
    l_conc_1 = tf.concat([l_conv_pep_1, l_conv_mhc_1], axis=1)
    l_conc_3 = tf.concat([l_conv_pep_3, l_conv_mhc_3], axis=1)
    l_conc_5 = tf.concat([l_conv_pep_5, l_conv_mhc_5], axis=1)
    l_conc_7 = tf.concat([l_conv_pep_7, l_conv_mhc_7], axis=1)
    l_conc_9 = tf.concat([l_conv_pep_9, l_conv_mhc_9], axis=1)

    l_conv_2_1 = tf.layers.conv1d(inputs=l_conc_1, filters=int(2*n_hid), kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_2_3 = tf.layers.conv1d(inputs=l_conc_3, filters=int(2*n_hid), kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_2_5 = tf.layers.conv1d(inputs=l_conc_5, filters=int(2*n_hid), kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_2_7 = tf.layers.conv1d(inputs=l_conc_7, filters=int(2*n_hid), kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)
    l_conv_2_9 = tf.layers.conv1d(inputs=l_conc_9, filters=int(2*n_hid), kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(), padding="same", activation=tf.nn.sigmoid)

    # max pooling:
    l_pool_max_1 = tf.reduce_max(l_conv_2_1,axis=1)
    l_pool_max_3 = tf.reduce_max(l_conv_2_3,axis=1)
    l_pool_max_5 = tf.reduce_max(l_conv_2_5,axis=1)
    l_pool_max_7 = tf.reduce_max(l_conv_2_7,axis=1)
    l_pool_max_9 = tf.reduce_max(l_conv_2_9,axis=1)

    # concatenate:
    l_conc = tf.concat([l_pool_max_1, l_pool_max_3, l_pool_max_5, l_pool_max_7, l_pool_max_9], axis=1)

    # dense hidden layer:
    l_dense = tf.layers.dense(inputs=l_conc, units=n_hid, activation=tf.nn.sigmoid)

    # output layer:
    out = tf.layers.dense(inputs=l_dense, units=1, activation=tf.nn.sigmoid)

    return out,l_in_pep,l_in_mhc


def build_FNN(max_pep_len, max_mhc_len, n_features, n_hid):

    # input:
    l_in_pep = tf.placeholder(tf.float32, shape=[None,max_pep_len,n_features])
    l_in_mhc = tf.placeholder(tf.float32, shape=[None,max_mhc_len,n_features])

    # concatenate and flatten peptide and MHC:
    l_conc=tf.reshape(tf.concat([l_in_pep, l_in_mhc], axis=1),[-1,(max_pep_len+max_mhc_len)*n_features])

    # dense hidden layer:
    l_dense = tf.layers.dense(inputs=l_conc, units=n_hid, activation=tf.nn.sigmoid)

    # output layer:
    out = tf.layers.dense(inputs=l_dense, units=1, activation=tf.nn.sigmoid)

    return out,l_in_pep,l_in_mhc
