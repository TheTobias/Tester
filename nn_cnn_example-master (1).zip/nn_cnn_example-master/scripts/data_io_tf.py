#!/usr/bin/env python

"""
Functions for data IO for neural network training.
"""

from __future__ import print_function
import argparse
import sys
import os
import time

from operator import add
import math
import numpy as np
#from scipy.io import netcdf
import tensorflow as tf


def read_MHCpTCR(filename):
    '''
    read data file with MHC-peptide-TCR data

    parameters:
        - filename : file with AA seq of peptide and TCR, MHC molecule name, target values (0 or 1) and partitioning
    returns:
        - peptides : list of peptide sequences
        - tcrs : list of TCRb sequences
        - mhcs : list of MHC molecule names
        - targets : np.array of target values
        - partitioning : np.array with the parititoning of the data
    '''

    # initialize variables:
    peptides=[]
    tcrs=[]
    mhcs=[]
    targets=[]
    partitioning=[]

    # read data:
    infile=open(filename,"r")
    for l in infile:
        l=l.strip().split("\t")
        if l[0] != "peptide":
            peptides.append(l[0])
            tcrs.append(l[1])
            mhcs.append(l[2])
            targets.append(float(l[3]))
            partitioning.append(int(l[4]))
    infile.close()

    # convert to numpy arrays:
    targets = np.array(targets)
    partitioning = np.array(partitioning)

    # return data:
    return peptides, tcrs, mhcs, targets, partitioning


def read_pTCR(filename):
    '''
    read data file with MHC-peptide-TCR data

    parameters:
        - filename : file with AA seq of peptide and TCR, target values (0 or 1) and partitioning
    returns:
        - peptides : list of peptide sequences
        - tcrs : list of TCRb sequences
        - targets : np.array of target values
        - partitioning : np.array with the parititoning of the data
    '''

    # initialize variables:
    peptides=[]
    tcrs=[]
    targets=[]
    partitioning=[]

    # read data:
    infile=open(filename,"r")
    for l in infile:
        l=l.strip().split("\t")
        if l[0] != "peptide":
            peptides.append(l[0])
            tcrs.append(l[1])
            targets.append(float(l[2]))
            partitioning.append(int(l[3]))
    infile.close()

    # convert to numpy arrays:
    targets = np.array(targets)
    partitioning = np.array(partitioning)

    # return data:
    return peptides, tcrs, targets, partitioning

def read_pMHC(filename):
    '''
    read data file with peptide-MHC data

    parameters:
        - filename : file with AA seq of peptide and TCR, MHC molecule name, target values (0 or 1) and partitioning
    returns:
        - peptides : list of peptide sequences
        - mhcs : list of MHC molecule names
        - targets : np.array of target values
        - partitioning : np.array with the parititoning of the data
    '''

    # initialize variables:
    peptides=[]
    mhcs=[]
    targets=[]
    partitioning=[]

    # read data:
    infile=open(filename,"r")
    for l in infile:
        l=l.strip().split("\t")
        if l[0] != "peptide":
            peptides.append(l[0])
            mhcs.append(l[1])
            try:
                targets.append(float(l[2]))
                partitioning.append(int(l[3]))
            except:
                pass
    infile.close()

    # convert to numpy arrays:
    targets = np.array(targets)
    partitioning = np.array(partitioning)

    # return data:
    return peptides, mhcs, targets, partitioning



def read_MHC_pseudo_seq(filename):
    '''
    read in MHC pseudo sequence

    parameters:
        - filename : file containing MHC pseudo sequences

    returns:
        - mhc : dictionnary mhc -> AA sequence (as string)
    '''
    # read MHC pseudo sequence:
    mhcfile=open(filename, "r")
    mhc={}

    for l in mhcfile:
        l=filter(None,l.strip().split())
        mhc[l[0]] = l[1]
    mhcfile.close()

    return mhc



def mhc_name2seq(mhc, mhc_table):
    '''
    translate MHC molecule names to amino acid sequence

    parameters:
        - mhc : list of MHC molecule names
        - mhc_table : file with MHC names and AA sequence

    returns:
        - mhc_aa : list of MHCs in amino acid sequences
    '''

    # get dictionnary of MHC name -> AA seq
    mhc_tab = read_MHC_pseudo_seq(mhc_table)

    # translate names:
    mhc_aa=[]
    for i in mhc:
        try:
            mhc_aa.append(mhc_tab[i])
        except:
            print("Unknown MHC molecule: " + str(i))
            mhc_aa.append("X")
    # return translated list:
    return mhc_aa



def read_blosum_MN(filename):
    '''
    read in BLOSUM matrix

    parameters:
        - filename : file containing BLOSUM matrix

    returns:
        - blosum : dictionnary AA -> blosum encoding (as list)
    '''

    # read BLOSUM matrix:
    blosumfile = open(filename, "r")
    blosum = {}
    B_idx = 99
    Z_idx = 99
    star_idx = 99

    for l in blosumfile:
        l = l.strip()

        if l[0] != '#':
            l= list(filter(None,l.strip().split(" ")))

            if (l[0] == 'A') and (B_idx==99):
                B_idx = l.index('B')
                Z_idx = l.index('Z')
                star_idx = l.index('*')
            else:
                aa = str(l[0])
                if (aa != 'B') &  (aa != 'Z') & (aa != '*'):
                    tmp = l[1:len(l)]
                    # tmp = [float(i) for i in tmp]
                    # get rid of BJZ*:
                    tmp2 = []
                    for i in range(0, len(tmp)):
                        if (i != B_idx) &  (i != Z_idx) & (i != star_idx):
                            tmp2.append(float(tmp[i]))

                    #save in BLOSUM matrix
                    [i * 0.2 for i in tmp2] #scale (divide by 5)
                    blosum[aa]=tmp2
    blosumfile.close()
    return(blosum)


def enc_list_bl(aa_seqs, blosum):
    '''
    blosum encoding of a list of amino acid sequences with padding

    parameters:
        - aa_seqs : list with AA sequences
        - blosum : dictionnary: key= AA, value= blosum encoding
    returns:
        - enc_aa_seq : list of np.ndarrays containing padded, encoded amino acid sequences
    '''

    # encode sequences:
    sequences=[]
    for seq in aa_seqs:
        e_seq=np.zeros((len(seq),len(blosum["A"])))
        count=0
        for aa in seq:
            if aa in blosum:
                e_seq[count]=blosum[aa]
                count+=1
            else:
                sys.stderr.write("Unknown amino acid in peptides: "+ aa +", encoding aborted!\n")
                sys.exit(2)
        sequences.append(e_seq)

    # pad sequences:
    max_seq_len = max([len(x) for x in aa_seqs])
    n_seqs = len(aa_seqs)
    n_features = sequences[0].shape[1]

    enc_aa_seq = np.zeros((n_seqs, max_seq_len, n_features))
    for i in range(0,n_seqs):
        enc_aa_seq[i, :sequences[i].shape[0], :n_features] = sequences[i]

    return enc_aa_seq


def enc_list_sparse(aa_seqs):
    '''
    blosum encoding of a list of amino acid sequences with padding

    parameters:
        - aa_seqs : list with AA sequences
    returns:
        - enc_aa_seq : list of np.ndarrays containing padded, encoded amino acid sequences
    '''

    # define sparse AA alphabet:
    alphabet=["A","R","N","D","C","Q","E","G","H","I","L","K","M","F","P","S","T","W","Y","V"]
    sparse={}
    count=0
    for aa in alphabet:
        sparse[aa]=np.ones(20)*0.05
        sparse[aa][count]=0.9
        count+=1
    sparse["X"]=np.ones(20)*0.05

    # encode sequences:
    sequences=[]
    for seq in aa_seqs:
        e_seq=np.zeros((len(seq),len(blosum["A"])))
        count=0
        for aa in seq:
            if aa in blosum:
                e_seq[count]=sparse[aa]
                count+=1
            else:
                sys.stderr.write("Unknown amino acid in peptides: "+ aa +", encoding aborted!\n")
                sys.exit(2)
        sequences.append(e_seq)

    # pad sequences:
    max_seq_len = max([len(x) for x in aa_seqs])
    n_seqs = len(aa_seqs)
    n_features = sequences[0].shape[1]

    enc_aa_seq = np.zeros((n_seqs, max_seq_len, n_features))
    for i in range(0,n_seqs):
        enc_aa_seq[i, :sequences[i].shape[0], :n_features] = sequences[i]

    return enc_aa_seq
