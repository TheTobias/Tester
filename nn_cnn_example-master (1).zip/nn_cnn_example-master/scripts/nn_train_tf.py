#!/usr/bin/env python

"""
Train feedforward neural network
"""

from __future__ import print_function
import argparse
import sys
import os
import time
import random
import re
import csv
from operator import itemgetter

import math
import numpy as np
from sklearn.preprocessing import normalize
from sklearn.metrics import roc_auc_score
import tensorflow as tf

import data_io_tf
import NN_tf

#config = tf.ConfigProto(intra_op_parallelism_threads=8, inter_op_parallelism_threads=8, allow_soft_placement=True, device_count = {'CPU': 8})
config = tf.ConfigProto(intra_op_parallelism_threads=2, inter_op_parallelism_threads=2, allow_soft_placement=True)
################################################################################
#   SUBROUTINES
################################################################################

def iterate_minibatches(pep, mhc, targets, batchsize):
    assert pep.shape[0] == mhc.shape[0] ==  targets.shape[0]
    # shuffle:
    indices = np.arange(len(pep))
    np.random.shuffle(indices)
    #for start_idx in range(0, len(pep) - batchsize + 1, batchsize):
    for start_idx in range(0, len(pep), batchsize):
        excerpt = indices[start_idx:start_idx + batchsize]
        yield pep[excerpt],mhc[excerpt],targets[excerpt]


################################################################################
#	PARSE COMMANDLINE OPTIONS
################################################################################

parser = argparse.ArgumentParser()
parser.add_argument('-infile', '--infile',  help="input file")
parser.add_argument('-outdir', '--outdir',  help="output directory")
parser.add_argument('-model', '--model',  help="Model architecture, default = FNN", default="FNN")
parser.add_argument('-n_hid', '--n_hid',  help="Size of 1st hidden layer, default = 50", default=50)
parser.add_argument('-batch_size', '--batch_size',  help="Mini batch size, default = 20", default=20)
parser.add_argument('-epochs', '--epochs',  help="Number of training epochs, default = 100", default=100)
parser.add_argument('-learning_rate', '--learning_rate',  help="Learning rate, default = 0.0001", default=0.0001)
parser.add_argument('-n_seed', '--n_seed',  help="Number of seeds, default = 1", default=1)
parser.add_argument('-encoding', '--encoding',  help="encoding, default = blosum", default="blosum")
parser.add_argument('-blosum', '--blosum', help="file with BLOSUM matrix")
parser.add_argument('-mhc_seq_table', '--mhc_seq_table',  help="file with MHC name -> MHC sequences", default='data/pseudosequences.all.X.dat')
parser.add_argument('-gpu', '--gpu', action="store_true", help="Use GPU, default = False", default=False)
#parser.add_argument('-raw', '--raw',  help="switch to print raw counts", action="store_true", default=False)
args = parser.parse_args()



# get input data (peps/proteins):
if args.infile != None:
    print("# Input: " + args.infile )
    inputfile = args.infile
else:
    sys.stderr.write("Please specify input!\n")
    sys.exit(2)

# get output data:
if args.outdir != None:
    print("# Output directory: " + args.outdir )
    outdir = args.outdir
else:
    sys.stderr.write("Please specify output directory!\n")
    sys.exit(2)

try:
    MODEL=args.model
    print("# Model architecture: " + str(MODEL))
except:
    sys.stderr.write("Problem with model architecture specification (option -model)!\n")
    sys.exit(2)


try:
    N_HID=int(args.n_hid)
    print("# number of hidden units: " + str(N_HID))
except:
    sys.stderr.write("Problem with number of hidden neurons specification (option -n_hid)!\n")
    sys.exit(2)

try:
    BATCH_SIZE=int(args.batch_size)
    print("# batch size: " + str(BATCH_SIZE))
except:
    sys.stderr.write("Problem with mini batch size specification (option -batch_size)!\n")
    sys.exit(2)

try:
    EPOCHS=range(1, int(args.epochs)+1)
    print("# number of training epochs: " + str(args.epochs))
except:
    sys.stderr.write("Problem with epochs specification (option -epochs)!\n")
    sys.exit(2)

try:
    LEARNING_RATE=float(args.learning_rate)
    print("# learning rate: " + str(LEARNING_RATE))
except:
    sys.stderr.write("Problem with learning rate specification (option -learning_rate)!\n")
    sys.exit(2)

try:
    SEED=range(1,(int(args.n_seed)+1))
    print("# number of seeds: " + str(int(args.n_seed)))
except:
    sys.stderr.write("Problem with number of seeds specification (option -learning_rate)!\n")
    sys.exit(2)

try:
    ENCODING=args.encoding
    print("# encoding: " + str(ENCODING))
except:
    sys.stderr.write("Problem with sequence encoding specification (option -encoding)!\n")
    sys.exit(2)

if ENCODING == "blosum":
    try:
        blosumfile=args.blosum
        print("# Blosum matrix file: " + str(blosumfile))
    except:
        sys.stderr.write("Blosum encoding requires blosum matrix file! (option -blosum)!\n")
        sys.exit(2)

mhc_table=args.mhc_seq_table
print("# MHC pseudo sequences: " + mhc_table)

# Set to GPU:
if args.gpu==True:
    device_name = "/gpu:0"
else:
    device_name = "/cpu:0"


# SET SEED:
np.random.seed(1)
tf.set_random_seed(1)


################################################################################
#   LOAD AND PARTITION DATA
################################################################################
print("# Loading data...")

# read data:
X_pep,X_mhc,y,part_vec=data_io_tf.read_pMHC(inputfile)
N_PART=len(set(part_vec))

# MHC name to sequence:
mhc_name=np.array(X_mhc)
X_mhc = data_io_tf.mhc_name2seq(X_mhc,mhc_table)

# save AA seqs
pep_aa = np.array(X_pep)

# encode data (list of numpy nd-arrays):
if ENCODING == "sparse":
    X_pep = data_io_tf.enc_list_sparse(X_pep)
    X_mhc = data_io_tf.enc_list_sparse(X_mhc)
elif ENCODING == "blosum":
    blosum = data_io_tf.read_blosum_MN(blosumfile)
    X_pep = data_io_tf.enc_list_bl(X_pep, blosum)
    X_mhc = data_io_tf.enc_list_bl(X_mhc, blosum)

# (n_datapoint, seq_len, n_features) 2 inp tensors
################################################################################
#   TRAIN 5-FOLD NESTED CV
################################################################################

# get these settings from parameter file:

N_FEATURES=X_pep.shape[2]
N_PARAM=-99
MAX_PEP_LEN=X_pep.shape[1]
MAX_MHC_LEN=X_mhc.shape[1]


for t in range(0,N_PART):
    for v in range(0,N_PART):
        if t != v:
            for s in SEED:
                print("# training with test parition: " + str(t) + " validation: " + str(v) + " seed: " + str(s))

                # get training and validation data:
                t_idx = np.where((part_vec != t) & (part_vec != v))
                v_idx = np.where(part_vec == v)

                X_pep_train=X_pep[t_idx]
                X_mhc_train=X_mhc[t_idx]
                y_train=y[t_idx]

                X_pep_val=X_pep[v_idx]
                X_mhc_val=X_mhc[v_idx]
                y_val=y[v_idx]

                print("shape training and validation set:")
                print(X_pep_train.shape)
                print(X_pep_val.shape)


                with tf.device(device_name):
                    # set up network:
                    if MODEL=="FNN":
                        predictions,l_in_pep,l_in_mhc = NN_tf.build_FNN(max_pep_len=MAX_PEP_LEN,max_mhc_len=MAX_MHC_LEN,n_features=N_FEATURES,n_hid=N_HID)
                    else:
                        print("Error: unknown model")

                    # CALCULATE LOSS:
                    targets = tf.placeholder(tf.float32, shape=[None,])
                    loss = tf.reduce_mean(tf.subtract(tf.reshape(targets, [-1]),tf.reshape(predictions, [-1]))**2)

                    # UPDATE WEIGHTS:
                    train_fn = tf.train.AdamOptimizer(learning_rate=LEARNING_RATE).minimize(loss)

                # save hyper parameters:
                model=np.array([MODEL])
                net_hyper_params=np.array([N_FEATURES, N_HID,MAX_PEP_LEN,MAX_MHC_LEN])


                # TRAINING LOOP:----------------------------------------------------
                # start tf session:
                sess = tf.Session(config=config)
                #sess = tf.Session()

                # variable initialization:
                sess.run(tf.global_variables_initializer())

                start_time = time.time()
                print("Training network test: " + str(t) + " validation: " + str(v) + " seed: " + str(s) + "..." )

                b_epoch=0
                b_train_err=99
                b_val_err=99

                for e in EPOCHS:

                    train_err = 0
                    train_batches = 0
                    val_err = 0
                    val_batches = 0
                    e_start_time = time.time()

                    # shuffle training examples and iterate through minbatches:
                    for inp in iterate_minibatches(X_pep_train, X_mhc_train, y_train, BATCH_SIZE):
                        pep, mhc, target = inp
                        _,tmp = sess.run([train_fn, loss], feed_dict={l_in_pep: pep, l_in_mhc: mhc, targets: target})
                        train_err += tmp
                        train_batches += 1

                    if e%2 == 0:
                        # predict validation set:
                        for inp in iterate_minibatches(X_pep_val, X_mhc_val, y_val, BATCH_SIZE):
                            pep, mhc, target = inp
                            val_err += sess.run(loss, feed_dict={l_in_pep: pep, l_in_mhc: mhc, targets: target})
                            val_batches += 1

                        # use early stopping, save only best model:
                        if (val_err/val_batches) < b_val_err:

                            # get model parameters:
                            param_vec=tf.trainable_variables()
                            param_vec=[x.eval(session=sess) for x in param_vec]
                            if N_PARAM < 0:
                                N_PARAM=len(param_vec)
                            param_vec = param_vec[(-1*N_PARAM):]

                            # save model:
                            np.savez(outdir + "params.t." + str(t) + ".v." + str(v) + ".s." + str(s) + ".npz", param_vec, model, net_hyper_params)
                            b_val_err = val_err/val_batches
                            b_train_err = train_err/train_batches
                            b_epoch = e

                        # print performance:
                        print("Epoch " + str(e) +
                        "\ttraining error: " + str(round(train_err/train_batches, 4)) +
                        "\tvalidation error: " + str(round(val_err/val_batches, 4)) +
                        "\ttime: " + str(round(time.time()-e_start_time, 3)) + " s")

                    else:
                        # print performance:
                        print("Epoch " + str(e) +
                        "\ttraining error: " + str(round(train_err/train_batches, 4)) +
                        "\ttime: " + str(round(time.time()-e_start_time, 3)) + " s")

                # print best performance:
                print("# Best epoch: " + str(b_epoch) +
                    "\ttrain error: " + str(round(b_train_err, 4)) +
                    "\tvalidation error: " + str(round(b_val_err, 4) ))
                # report total time used for training:
                print("# Time for training: " + str(round((time.time()-start_time)/60, 3)) + " min" )
                # close session:
                sess.close()
                tf.reset_default_graph()



################################################################################
#   PREDICT NETWORKS
################################################################################

# prepare output file:
outfile=open(outdir + "predictions.txt","w")
outfile.write("peptide\tmhc\ttarget\tprediction\n")

# initialize variables for AUC calculation:
y_test_all=[]
pred_vec_all=[]

# predict all partitions:
for t in range(0,N_PART):
    print("# predicting test set " + str(t) + "...")
    # get test set:
    test_idx = np.where(part_vec == t)

    X_pep_test = X_pep[test_idx]
    X_mhc_test = X_mhc[test_idx]
    y_test = y[test_idx]

    pep_test_aa = pep_aa[test_idx]
    mhc_test_name = mhc_name[test_idx]

    all_pred=[]
    for v in range(0,N_PART):
        if t != v:
            for s in SEED:

                # set up network:
                MODEL = np.load(outdir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_1']
                hyper_params = np.load(outdir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_2']
                N_FEATURES=int(hyper_params[0])
                N_HID=int(hyper_params[1])
                MAX_PEP_LEN=int(hyper_params[2])
                MAX_MHC_LEN=int(hyper_params[3])

                with tf.device(device_name):
                    if MODEL=="FNN":
                        predictions,l_in_pep,l_in_mhc = NN_tf.build_FNN(max_pep_len=MAX_PEP_LEN,max_mhc_len=MAX_MHC_LEN,n_features=N_FEATURES,n_hid=N_HID)
                    else:
                        print("Error: unknown model")
                # start tf session:
                sess = tf.Session(config=config)
                #sess = tf.Session()
                # variable initialization:
                sess.run(tf.global_variables_initializer())

                # set parameters:
                best_params = np.load(outdir + "params.t." + str(t) +  ".v." + str(v) + ".s." + str(s) + ".npz")['arr_0']
                params=tf.trainable_variables()

                for i in range(0,len(params)):
                    sess.run(params[i].assign(best_params[i]))

                # predict model:
                all_pred.append( sess.run(predictions, feed_dict={l_in_pep: X_pep_test, l_in_mhc: X_mhc_test}) )
                # close session:
                sess.close()
                tf.reset_default_graph()

    # calculate mean predictions of all models:
    all_pred=np.array(all_pred)
    pred = np.mean(all_pred, axis=0)

    # save pred and target
    y_test_all.append(list(y_test))
    pred_vec_all.append(list(pred))


    for i in range(0,pep_test_aa.shape[0]):
        outfile.write(str(pep_test_aa[i]) + "\t" + str(mhc_test_name[i]) + "\t" + str(y_test[i]) + "\t" + str(pred[i][0]) + "\n")

# save and calculate performance (AUC):
tmp = [item for sublist in y_test_all for item in sublist]
y_test_all=np.array(tmp)
y_binary = np.where(y_test_all>=0.42562, 1,0)

tmp = [item for sublist in pred_vec_all for item in sublist]
pred_vec_all = np.array(tmp)


auc = roc_auc_score(y_binary, pred_vec_all)
outfile.write("# AUC: " + str(auc) + "\n")
outfile.close()
